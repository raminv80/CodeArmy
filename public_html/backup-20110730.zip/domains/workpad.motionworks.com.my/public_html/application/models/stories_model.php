<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stories_model extends CI_Model { 
	
	var $data = '';
	
	function __construct() {
		parent::__construct();
	}
	
	// - create new stories
	function create_user_story($creator_id) {
		// make random id for work_id
		$work_id = $this->_gen_id();
		$check_work_id = $this->get_work($work_id);
		while($check_work_id->num_rows() > 1) {
			$work_id = $this->_gen_id();
			$check_work_id = $this->get_work($work_id);			
		}
		
		$doc = array(
			"work_id" => $work_id,
			"title" => $this->input->post('title'),
			"type" => $this->input->post('type'),
			"description" => $this->input->post('description'),
			"points" => $this->input->post('points'),
			"cost" => $this->input->post('cost'),
			"status" => 'open',
			"creator" => $creator_id,
			"owner" => $creator_id,
			"project_id" => '1', // temporary...
			"created_at" => date('Y-m-d H:i:s') 
		); 
		
		if($this->db->insert('works', $doc)) {
			return $doc['work_id'];		
		} else {
			return false;
		}
		
	}
	
	function edit_user_story($id) {
		
		$doc = array(
			"title" => $this->input->post('title'),
			"type" => $this->input->post('type'),
			"description" => $this->input->post('description'),
			"points" => $this->input->post('points'),
			"cost" => $this->input->post('cost'),
			"project_id" => '1', // temporary...
		); 
		
		if($this->db->update('works', $doc, array('work_id' => $id))) {
			return $id;		
		} else {
			return false;
		}
		
	}
	
	// - get stories
	function get_work($work_id) {
		return $this->db->get_where('works', array('work_id' => $work_id));
	}
	
	// - get work details
	function get_work_details($work_id) {
		$sql = "SELECT * FROM works, users, project WHERE works.work_id = ? AND users.user_id = works.creator AND works.project_id = project.project_id";
		$result = $this->db->query($sql, array($work_id));
		return $result;
	}
	
	// - get work list
	function get_works_list($status='') {
                if($status == '') {
		$sql = "SELECT * FROM works, users WHERE users.user_id = works.creator ORDER BY works.priority DESC";
        $result = $this->db->query($sql);   
                }elseif($status=='In progress'){
		$sql = "SELECT * FROM works, users WHERE users.user_id = works.creator AND works.status in ('In progress','Redo') ORDER BY works.priority DESC";
		$result = $this->db->query($sql);
                }elseif($status=='Done'){
		$sql = "SELECT * FROM works, users WHERE users.user_id = works.creator AND works.status in ('Done','Verify') ORDER BY works.priority DESC";
		$result = $this->db->query($sql);
                }elseif($status=='Open'){
		$sql = "SELECT * FROM works, users WHERE users.user_id = works.creator AND works.status in ('open','Open', 'Reject') ORDER BY works.priority DESC, works.work_id ASC";
		$result = $this->db->query($sql);
                }else {
		$sql = "SELECT * FROM works, users WHERE users.user_id = works.creator AND works.status = ? ORDER BY works.priority DESC";
		$result = $this->db->query($sql, $status); 
                }
		return $result;
	}
	
	// - store uploaded file data
	function store_uploaded_file($file_data) {
		$doc = array(
			"file_id" => md5(microtime()),
			"file_type" => $file_data['file_type'],
			"file_name" => $file_data['file_name'],
			"file_title" => $file_data['file_title'],
			"file_description" => $file_data['file_description'],
			"created_at" => date('Y-m-d H:i:s'),
			"work_id" => $file_data['work_id']
		);
		
		return $this->db->insert('work_files', $doc);
	}
	
	
	// - get uploaded files
	function get_uploaded_files($work_id) {
		$sql = "SELECT * FROM work_files WHERE work_id = ? ORDER BY created_at DESC";
		$result = $this->db->query($sql, array($work_id));
		return $result;
	}
	
	// - get uploaded file detail
	function get_uploaded_file($file_id) {
		return $this->db->get_where('work_files', array('file_id' => $file_id));
	}
	
	// - delete uploaded files
	function delete_uploaded_file() {
		
	}
	
	//-----------------------------------------------------------------------//
	// generate work id
	function _gen_id() {
		$work_id = '';
		list($usec, $sec) = explode(' ', microtime());
		$rand_seed = (float)$sec + ((float)$usec * 100000);
		mt_srand($rand_seed);
		for ($r = 0; $r<6; $r++) { $work_id .= mt_rand(0,9); }
		return $work_id;
	}
	
	//function get projects
	function get_project_name($pid) {
		$query = "SELECT project_name FROM project WHERE project_id = ?";
		$result = $this->db->query($query, array($pid));
		return $result;
	}
	
	// function delete work
	function delete_confirm($id) {
		$query = "DELETE FROM works WHERE work_id = ?";
		$result = $this->db->query($query, array($id));
		return $result;
	}
	
	//check owner
	function check_owner($pro_id, $user_id) {
		$query = "SELECT * FROM project WHERE project_id = ? AND project_owner_id = ?";
		$result = $this->db->query($query, array($pro_id, $user_id));
		return $result;
	}
	
	//check admin
	function check_admin($story_id, $user_id) {
		$query = "SELECT * FROM works WHERE work_id = ? AND creator = ?";
		$result = $this->db->query($query, array($story_id, $user_id));
		return $result;
	}
	
	function get_comments($pro_id) {
		$query = "SELECT * FROM comments WHERE story_id = ? ORDER BY comment_created DESC";
		$result = $this->db->query($query, array($pro_id));
		return $result;
	}
	
	function create_comment() {
		$doc = array(
			'story_id' => $this->input->post('story_id'),
			'username' => $this->input->post('user_id'),
			'comment_body' => $this->input->post('comments')
		);
		return $this->db->insert('comments', $doc);
	}
	
	function make_bid() {
		$datetime = date('Y-m-d H:i:s');
		$doc = array(
			'work_id' => $this->input->post('work_id'),
			'user_id' => $this->input->post('user_id'),
			'bid_cost' => $this->input->post('set_cost'),
                        'days' => $this->input->post('set_days'),
			'created_at' => $datetime,
			'bid_status' => 'Bid'
		);
		return $this->db->insert('bids', $doc);
	}
	
	function get_bids($work_id) {
		$query = "SELECT a.*, b.username, works.status as work_status FROM bids a, users b, works WHERE a.work_id = ? AND a.user_id = b.user_id AND works.work_id=a.work_id ORDER BY bid_cost ASC, days ASC, bid_status ASC";
		$result = $this->db->query($query, array($work_id));
		return $result;
	}
	
	function get_bid($bid_id){
		$query = "SELECT * FROM bids where bid_id = ? ORDER BY bid_cost DESC";
		$result = $this->db->query($query, array($bid_id));
		return $result;	
	}
        
        function get_work_from_bid($id) {
            $query = "SELECT work_id FROM bids WHERE bid_id = ?";
            $result = $this->db->query($query, array($id));
	    return $result;
            
        }
        
        function accept_bid($id , $work_id) {
            $query = "UPDATE bids SET bid_status = 'Accepted' WHERE bid_id = ?";
            $query2 = "UPDATE works SET status = 'In Progress' WHERE work_id = ?";
            $result = $this->db->query($query, array($id));
            $result2 = $this->db->query($query2, array($work_id));
	    return $result;
        }
		
		function get_my_works($user_id, $status){
			if($status == 'In progress'){
			$query = "SELECT * FROM bids, works where bids.work_id = works.work_id and bids.user_id = ?  and bids.bid_status = 'Accepted' and works.status in ('In progress', 'Redo')";
			$result = $this->db->query($query, array($user_id));
			}elseif($status=='Done'){
			$query = "SELECT * FROM bids, works where bids.work_id = works.work_id and bids.user_id = ?  and bids.bid_status = 'Accepted' and works.status in ('Done','Verify')";
			$result = $this->db->query($query, array($user_id));
			}else{
			$query = "SELECT * FROM bids, works where bids.work_id = works.work_id and bids.user_id = ? and bids.bid_status = 'Accepted' and works.status = ?";
			$result = $this->db->query($query, array($user_id,$status));
			}
			
			return $result;
		}
		
		function done($id){
			$query = "update works set status = 'Done' where work_id = ?";
			$result = $this->db->query($query, array($id));
			return $result;
		}
		
		function redo($id){
			$query = "update works set status = 'Redo' where work_id = ?";
			$result = $this->db->query($query, array($id));
			return $result;
		}
		
		function verify($id){
			$query = "update works set status = 'Verify' where work_id = ?";
			$result = $this->db->query($query, array($id));
			return $result;
		}
		
		function signoff($id){
			$query = "update works set status = 'Signoff' where work_id = ?";
			$result = $this->db->query($query, array($id));
			return $result;
		}
		
		function reject($id){
			$query = "update works set status = 'Reject' where work_id = ?";
			$result = $this->db->query($query, array($id));
			return $result;
		}
		
		function get_user_email($work_id){
			$query = "select users.user_id, email,username from works, users, bids where bids.user_id = users.user_id and bids.work_id = works.work_id and works.work_id = ? and bids.bid_status = 'Accepted'";
			$result = $this->db->query($query, array($work_id));
			return $result;			
		}
		
}