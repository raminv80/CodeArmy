<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Projects_model extends CI_Model { 
	
	var $data = '';
	
	function __construct() {
		parent::__construct();
	}
	
	function get_projects($user_id) {
		$query = "SELECT * FROM project WHERE project_owner_id=?";
		$result = $this->db->query($query, array($user_id));
		return $result;
	}
	
	function get_worklists($project_id) {
		$query = "SELECT * FROM works WHERE project_id = ? ORDER BY priority DESC";
		$result = $this->db->query($query, array($project_id));
		return $result;
	}
	
	function save_priority() {
		$query = "UPDATE works SET priority = ? WHERE work_id = ?";
		$result = $this->db->query($query, array($this->input->post('priority'), $this->input->post('work_id')));
		return $result;
	}
	
	function log_history($user_id, $project_id, $work_id, $event, $status=0, $desc = ''){
		$log = array(
			"user_id" => $user_id,
			"work_id" => $work_id,
			"event" => $event,
			"status" => $status,
			"project_id" => $project_id,
			"Desc" => $desc,
			"created_at" => date('Y-m-d H:i:s')
		); 
		if($this->db->insert('history', $log)) {
			return $log['user_id'];
		} else {
			return false;
		}
	}
}