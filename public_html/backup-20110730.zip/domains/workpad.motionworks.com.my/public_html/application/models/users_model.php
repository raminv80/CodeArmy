<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users_model extends CI_Model { 
	var $data = '';
	
	function __construct() {
		parent::__construct();
	}
	
	// create new user 
	public function create_new_user() {
	    $user_id = md5(microtime());
		$doc = array(
			"user_id" => $user_id,
			"username" => strtolower($this->input->post('username')),
			"secret" => md5($this->input->post('password')),
			"email" => strtolower($this->input->post('email')),
			"created_at" => date('Y-m-d H:i:s')
		); 
		$this->create_new_profile($user_id);
		return $this->db->insert('users', $doc);
	}
	
	// create new profiles
	public function create_new_profile($user_id) {
		$doc = array(
			"user_id" => $user_id
		); 
		return $this->db->insert('user_profiles', $doc);
	}
	
	
	// get user data
	public function get_user($q = '', $request_type = 'user_id') {
		switch($request_type) {
			case 'user_id':
				$query = $this->db->get_where('users', array('user_id' => $q));
				break;
			
			case 'email': 
				$query = $this->db->get_where('users', array('email' => $q));
				break;
				
			case 'username':
				$query = $this->db->get_where('users', array('username' => $q));
				break;
				
			default: 
				$query = false;
				break;
		}
		
		if($query) {
			if($query->num_rows() > 0) {
				$result = $query; 
			} else { $result = false; }
		} else { $result = false; }
		
		return $result;
 	}
	
	//validate login
	function validate() {
		$this->db->where('username', $this->input->post('username'));
		$this->db->where('secret', md5($this->input->post('password')));
		$query = $this->db->get('users');
		if($query->num_rows == 1) {
			return $query;
		}
		else {
			return false;
		}
	}
		
	//get profile	
	function get_profile($user_id) {
		$this->db->where('user_id', $user_id);
		$query = $this->db->get('user_profiles');
		if($query->num_rows == 1) {
				return $query;
			}
			else {
				return false;
			}		
	}
	
	//update profile
	function update_profile($user_id) {
		$contact = array(
			"mobile_no" => $this->input->post('mobile_no'),
			"city" => $this->input->post('city'),
			"country" => $this->input->post('country')
			);
		
		$urls = array(
			"facebook" => $this->input->post('fb_url'),
			"twitter" => $this->input->post('twit'),
			"linkedin" => $this->input->post('linkedin'),
			"github" => $this->input->post('github'),
			"portfolio" => $this->input->post('portfolio')						
		);
		
		$contact = json_encode($contact);
		$urls = json_encode($urls);
		
		$doc = array(
			"full_name" => $this->input->post('full_name'),
			"bank_name" => $this->input->post('bank_name'),
			"bank_acc" => $this->input->post('bank_acc'),
			"paypal_acc" => $this->input->post('paypal'),
			"contact" => $contact,
			"urls" => $urls
		);
		return $this->db->update('user_profiles', $doc, array('user_id' => $user_id));
	}
	
	function update_password($user_id) {
		$secret = md5($this->input->post('n_pwd'));
		$doc2 = array(
			"secret" => $secret
		);
		
		return $this->db->update('users', $doc2, array('user_id' => $user_id));
	}
	
	function have_project($user_id) {
		$query = "SELECT * FROM project WHERE project_owner_id = ?";
		$result = $this->db->query($query, array($user_id));
		
		if($result->num_rows() > 0) {
			return true;
		}
	}
	
}