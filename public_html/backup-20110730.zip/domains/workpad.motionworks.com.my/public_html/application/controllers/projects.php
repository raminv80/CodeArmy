<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Projects extends CI_Controller {
	var $view_data = array();
	
	function __construct() {
		parent::__construct();
		$this->load->model('users_model');
		$this->load->model('projects_model');
		$this->load->model('stories_model', 'stories');
		
		$this->view_data['page_is'] = 'signup';
		
		// - check if user is logged in
		$check_login = $this->session->userdata('is_logged_in');
		if($check_login == true) {
			$this->view_data['username'] = $this->session->userdata('username');
		} else { // - if user not login, redirect to dashboard. 
			redirect("dashboard"); 
		}
	}
	
	function index() {
		$user_id = $this->session->userdata('user_id');
		$this->view_data['window_title'] = "Workpad :: Projects Created";
		
		//get projects created
		$q_projects = $this->projects_model->get_projects($user_id);
		if($q_projects->num_rows() > 0) {
			$this->view_data['projects'] = $q_projects->result_array();
		} 
		else {
			$this->view_data['error'] = "You did not have any projects created yet";
		}
		
		//show the page
		$this->load->view('projects_view', $this->view_data);

	}
	
	function view($project_id) {
		$user_id = $this->session->userdata('user_id');
		$this->view_data['window_title'] = "Workpad :: Project";
		$this->view_data['pro_id'] = $project_id;
		//$query = $this->projects_model->priority_sort()
		
		if($this->stories->check_owner($project_id, $user_id)->num_rows() > 0) {
			$this->view_data['create_button'] = true;
		}
		else {
			$this->view_data['create_button'] = false;
		}
		
		$q_worklist = $this->projects_model->get_worklists($project_id);
		if($q_worklist->num_rows() > 0) {
			$this->view_data['worklist'] = $q_worklist->result_array();
		} 
		
		$this->load->view('project_view', $this->view_data);
	}
	
	function priority() {		
		$this->projects_model->save_priority();
		redirect("/projects/view/".$this->input->post('project_id'));
	}

}