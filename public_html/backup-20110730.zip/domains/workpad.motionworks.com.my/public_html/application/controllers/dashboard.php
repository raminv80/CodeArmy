<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	var $view_data = array();
	
	function __construct() {
		parent::__construct();
		$this->load->model('users_model');
		
		$this->view_data['page_is'] = 'dashboard';
		
		// - check to verify if user is login...
		$check_login = $this->session->userdata('is_logged_in');
		if($check_login == true) {
			$this->view_data['username'] = $this->session->userdata('username');
		}
		$this->load->model('stories_model', 'stories');
	}
	
	// index page
	function index() {
		$user_id = $this->session->userdata('user_id');
		$query = $this->stories->get_works_list('Open');
                $this->view_data['open_empty'] = "";
                $this->view_data['progress_empty'] = "";
                $this->view_data['done_empty'] = "";
                $this->view_data['signoff_empty'] = "";
                        
		if($query->num_rows() > 0) {
			$this->view_data['work_list_open'] = $query->result_array();
		}else {
                    $this->view_data['open_empty'] = true;
        }
        
		$query2 = $this->stories->get_works_list('In progress');
		if($query2->num_rows() > 0) {
			$this->view_data['work_list_progress'] = $query2->result_array();
		} 
                 else {
                    $this->view_data['progress_empty'] = true;
                }
                $query3 = $this->stories->get_works_list('Done');
		if($query3->num_rows() > 0) {
			$this->view_data['work_list_done'] = $query3->result_array();
		} 
                 else {
                    $this->view_data['done_empty'] = true;
                }
                $query4 = $this->stories->get_works_list('Signoff');
		if($query4->num_rows() > 0) {
			$this->view_data['work_list_signoff'] = $query4->result_array();
		} 
                 else {
                    $this->view_data['signoff_empty'] = true;
                }
		$this->view_data['have_project'] = $this->users_model->have_project($user_id);
		$this->view_data['window_title'] = 'Workpad';
		$this->load->view('dashboard_view', $this->view_data);
	}	
	
	function feedback(){
		$user_id = $this->session->userdata('user_id');
		$query = $this->users_model->get_user($user_id);
		$user_data = $query->result_array();
		$this->view_data['user_data'] = $user_data;
		$this->view_data['window_title'] = 'Feedback on Workpad';
		$this->load->view('feedback_view', $this->view_data);
	}
	
	function statistics($user_id){
		$this->view_data['window_title'] = 'Statistics';
		$this->load->view('statistics_view', $this->view_data);		
	}
}