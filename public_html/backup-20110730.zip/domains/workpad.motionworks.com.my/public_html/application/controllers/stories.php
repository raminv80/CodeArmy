<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stories extends CI_Controller {
	
	var $view_data = array();
	
	function __construct() {
		parent::__construct();
		$this->load->model('users_model');
		$this->load->model('projects_model');
		
		$this->view_data['page_is'] = 'stories';
		
		// - check if user is logged in
		$check_login = $this->session->userdata('is_logged_in');
		if($check_login == true) {
			$this->view_data['username'] = $this->session->userdata('username');
		} else { // - if user not login, redirect to dashboard. 
			redirect("dashboard"); 
		}	
		$this->load->model('stories_model', 'stories');
	}
	
	
	// - stories index page
	function index() {
		echo "stories index page";
	}
	
	
	// - add stories 
	function create($id="") {
		$user_id = $this->session->userdata('user_id');
		
		//check whether the user have project
		if($this->users_model->have_project($user_id) == true) {
				//check if there is argument
				if($id != "") {
					if($this->stories->check_owner($id, $user_id)->num_rows() > 0) {
						//echo $this->stories->check_owner($id, $user_id)->num_rows();
						$query4 = $this->stories->get_project_name($id);
						$this->view_data['project'] = $query4->result_array();
						$this->view_data['projects'] = "";
						if($this->input->post('submit')) {
							$this->load->library('form_validation');
		
							$this->form_validation->set_rules('title', 'Title', 'required');
							$this->form_validation->set_rules('type', 'Type', 'required');
							$this->form_validation->set_rules('description', 'Description', 'required');
							$this->form_validation->set_rules('points', 'Complexity Points', 'required');
							$this->form_validation->set_rules('cost', 'Cost', 'required');
							
							if ($this->form_validation->run() == FALSE) {
								$this->view_data['form_error'] = true;
							} else {
								$work_id = $this->stories->create_user_story($this->session->userdata('user_id'));
								if($work_id != false) {
									// signup successful
									$this->view_data['success'] = true;
									$this->view_data['work_id'] = $work_id;
								} else { // - if there is a problem writing to db
									redirect(base_url()."error");
								}
							}
						}
						
						$this->view_data['window_title'] = "Workpad :: Create User Stories";
						$this->load->view('stories_new_view', $this->view_data);
					
					}
					else {
						echo "Error";
					}
				}
				//else { echo "No argument"; }
			else {
				$query1 = $this->projects_model->get_projects($user_id);
				$this->view_data['projects'] = $query1->result_array();
				$this->view_data['project'] = "";
				if($this->input->post('submit')) {
						$this->load->library('form_validation');

						$this->form_validation->set_rules('project', 'Project', 'required');
						$this->form_validation->set_rules('title', 'Title', 'required');
						$this->form_validation->set_rules('type', 'Type', 'required');
						$this->form_validation->set_rules('description', 'Description', 'required');
						$this->form_validation->set_rules('points', 'Complexity Points', 'required');
						$this->form_validation->set_rules('cost', 'Cost', 'required');
						
						if ($this->form_validation->run() == FALSE) {
							$this->view_data['form_error'] = true;
						} else {
							$work_id = $this->stories->create_user_story($this->session->userdata('user_id'));
							if($work_id != false) {
								// signup successful
								$this->view_data['success'] = true;
								$this->view_data['work_id'] = $work_id;
							} else { // - if there is a problem writing to db
								redirect(base_url()."error");
							}
						}
					}
					
					$this->view_data['window_title'] = "Workpad :: Create User Stories";
					$this->load->view('stories_new_view', $this->view_data);
			}
		}
	}
}