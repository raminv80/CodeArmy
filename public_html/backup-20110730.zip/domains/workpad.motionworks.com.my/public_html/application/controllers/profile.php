<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends CI_Controller {
	
	var $view_data = array();
	
	function __construct() {
		parent::__construct();
		$this->load->model('users_model');
		
		$this->view_data['page_is'] = 'signup';
		
		// - check if user is logged in
		$check_login = $this->session->userdata('is_logged_in');
		if($check_login == true) {
			$this->view_data['username'] = $this->session->userdata('username');
		} else { // - if user not login, redirect to dashboard. 
			redirect("dashboard"); 
		}
	}
	
	// - profile index function
	function index() {
	    $user_id = $this->session->userdata('user_id');
	    //$query = $this->users_model->get_user();
		$query = $this->users_model->get_profile($user_id);
		//print_r($query);
		$data = $query->result_array();
		$this->view_data['window_title'] = "Workpad :: user profile";
		//$this->view_data['user_id'] = $user_id;
		$this->view_data['profile'] = $data[0];
		
		$this->load->view('profile_view', $this->view_data);
	}
	
	// - edit profile page
	function edit() {
		$this->load->helper('country_helper');
		$user_id = $this->session->userdata('user_id');
		$query = $this->users_model->get_profile($user_id);
		$data = $query->result_array();
		$this->view_data['profile'] = $data[0];
		$this->view_data['window_title'] = "Workpad :: edit user profile";
		
		if($this->input->post('submit')) {

					if($this->users_model->update_profile($user_id)) {
						redirect (base_url()."profile");
					} else { // - if there is a problem writing to db
						redirect(base_url()."error");
					} 
				
		}
		
		$this->load->view('profile_edit_view', $this->view_data);
	}
	
	function edit_password() {
		$this->view_data['window_title'] = "Workpad :: edit user password";
		
		if($this->input->post('submit2')) {
				$this->load->library('form_validation');
				$this->form_validation->set_rules('o_pwd', 'Old Password', 'required|min_length[6]|callback__check_opwd');
				$this->form_validation->set_rules('n_pwd', 'New Password', 'required|min_length[6]|matches[r_pwd]');
				$this->form_validation->set_rules('r_pwd', 'Repeat Password', 'required|min_length[6]');
				if ($this->form_validation->run() == FALSE) {
					$this->view_data['form_error'] = true;
				} else {
					if($this->users_model->update_password($user_id)) {
						redirect (base_url()."profile");
					} else { // - if there is a problem writing to db
						redirect(base_url()."error");
					} 
				}
		}
		
		$this->load->view('profile_editpwd_view', $this->view_data);
	
	}
	
	function _check_opwd($opwd) {
	$query = $this->users_model->get_user($this->session->userdata('user_id'), 'user_id');
	$data = $query->result_array();
	$opwd = md5($opwd);
		if($opwd != $data[0]['secret']) {
			$this->form_validation->set_message('_check_opwd', 'Wrong Password');
			return false;
		} else { return true; }
	}
	
}	