<?php $this->load->view('includes/header_view'); ?>
	
	<!-- error story page -->
	<div>
		<h2>Error... user stories does not exists</h2>
	</div>
	<!-- error story page -->

<?php $this->load->view('includes/footer_view'); ?>