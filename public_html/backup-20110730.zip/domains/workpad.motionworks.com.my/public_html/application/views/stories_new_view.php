<?php $this->load->view('includes/header_view'); ?>

	<!-- add new stories form container start -->
	<div id="story-wrapper">
		<div id="content"></div>
		
		<?php if(isset($success)): ?>
		
		<div class="story_created"><h2>Done!</h2><p>New user stories created.</p> <a href="/story/<?php echo $work_id; ?>">view details</a></div>
		
		<?php else: ?>
				
		<h2>Create New User Story</h2>
		
		<?php if(validation_errors()) { ?>
		<!-- form error container start -->
		<div class="val-error">
			<?php echo validation_errors(); ?>
		</div>
		<!-- form error container ends -->
		<?php } ?>
		
		<?php echo form_open("/stories/create"); ?>
		<div class="new-story_field">
		<label for="Project">Project</label>
			<?php if($project) { 
					echo $project[0]['project_name'];
			} ?>
			<?php if($projects) { ?>
			<select name="project">
			<?php foreach($projects as $project) { ?>
					<option value = "<?php echo $project['project_id']; ?>"><?php echo $project['project_name']; ?></option>				
		<?php } } ?>
			</select>
		</div>
		
		
		<div class="new-story_field">
			<label for="title">Title</label>
			<input type="text" name="title" value="<?php echo $this->input->post('title'); ?>" placeholder="title" id="title" />
			<p></p>
		</div>

		<div class="new-story_field">
			<label for="type">Type</label>
			<select name="type">
			<option value="Feature">Feature</option>
			<option value="Chore">Chore</option>
			<option value="Bug">Bug</option>
			<option value="Milestone">Milestone</option>
			</select>
		</div>
		
		<div class="new-story_field">
			<label for="description">Description</label>
			<textarea name="description" rows="8" cols="40"><?php echo $this->input->post('description'); ?></textarea>
		</div>
		
		<div class="new-story_field">
			<label for="points">Complexity Points</label>
			<select name="points">
			<option value="1">1 point</option>
			<option value="2">2 points</option>
			<option value="3">3 points</option>
			<option value="5">5 points</option>
			<option value="8">8 points</option>
			<option value="13">13 points</option>
			<option value="20">20 points</option>
			<option value="40">40 points</option>
			</select>
		</div>
		
		<div class="new-story_field">
			<label for="cost">Cost</label>
			RM <input type="text" name="cost" value="<?php echo $this->input->post('cost'); ?>" placeholder="450" id="points" />
		</div>
		
		<div class="new-story_field">
			<label for="submit">&nbsp;</label>
			<input type="submit" name="submit" value="Create Story" id="submit" />
			<p></p>
		</div>
		
		<?php echo form_close(); ?>
		
		<?php endif; ?>
		
		</div>
	</div>
	<!-- / add new stories form container ends -->
		
<?php $this->load->view('includes/footer_view'); ?>