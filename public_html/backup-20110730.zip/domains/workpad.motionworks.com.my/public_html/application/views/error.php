<?php $this->load->view('includes/header_view'); ?>
	
<h2>404 : This is not the page that you're not looking for.</h2>

<?php $this->load->view('includes/footer_view'); ?>