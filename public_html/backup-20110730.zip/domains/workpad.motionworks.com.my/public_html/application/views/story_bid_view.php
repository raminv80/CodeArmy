<?php $this->load->view('includes/header_view'); ?>

	<!-- bid for stories start -->
	<div id="bid-wrapper">
		<div id="content">
			
		<h2>Bid for <?php echo $work_data['title']; ?></h2>
		
		<div class="desc">
			<p><?php echo $work_data['description']  ?></p>
		</div>
		
		<div class="points">
			Complexity points: <?php echo $work_data['points']; ?> | Cost: RM<?php echo $work_data['cost']; ?>
		</div>
		
		<?php echo form_open('story/setbid'); ?>
		
		<div class="cost">
			Set your cost:
		RM
		<input type="text" size="4" name="set_cost" value="<?php echo $work_data['cost']; ?>" id="set_cost" /></div>
                <div class="cost">
			Set number of days:
		<input type="text" size="4" name="set_days" id="set_days" /> days
                </div>
		<div class="cost">
			<input type="hidden" name="work_id" value="<?php echo $work_data['work_id'];?>" />
			<input type="hidden" name="user_id" value="<?php echo $this->session->userdata('user_id'); ?>" id="user_id">	
			<input type="submit" name="submit" value="Bid Now" id="submit" />
		</div>
		</div>
		
		<?php echo form_close(); ?>
		
		</div>
	</div>
	<!-- bid for stories ends -->

<?php $this->load->view('includes/footer_view'); ?>