
    <script type="text/javascript" src='http://jqueryjs.googlecode.com/files/jquery-1.2.6.min.js'></script>
    <script type="text/javascript" src='<?php echo base_url() ?>public/scripts/jquery-ui-personalized-1.6rc2.min.js'></script>
    <script type="text/javascript" src='<?php echo base_url() ?>public/scripts/inettuts.js'></script>	
</body>
</html>