<?php $this->load->view('includes/header_view'); ?>

	<!-- add new stories form container start -->
	<div id="story-wrapper">
		<div id="content">
        	<iframe src="https://spreadsheets.google.com/spreadsheet/embeddedform?formkey=dHRURzdoS1gxUXRiamlJVm9COFFUM2c6MQ" width="760" height="723" overflow="hidden">Loading...</iframe>
        </div>
	</div>
<?php $this->load->view('includes/footer_view'); ?>